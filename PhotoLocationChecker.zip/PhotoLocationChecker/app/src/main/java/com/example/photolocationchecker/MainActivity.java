package com.example.photolocationchecker;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.MimeType;
import com.zhihu.matisse.engine.impl.GlideEngine;
import com.zhihu.matisse.filter.Filter;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import java.security.Permissions;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_CHOOSE = 23;
    private String[] PerssionGroup;
    ImageView show_pic_image_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PerssionGroup =new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE};
        requestPermission(PerssionGroup);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        show_pic_image_view =findViewById(R.id.show_pic_image_view);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Matisse.from(MainActivity.this)
                        .choose(MimeType.ofAll())
                        .countable(true)
                        .maxSelectable(9)
                        .addFilter(new GifSizeFilter(320, 320, 5 * Filter.K * Filter.K))
                        .gridExpectedSize(getResources().getDimensionPixelSize(R.dimen.grid_expected_size))
                        .restrictOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                        .thumbnailScale(0.85f)
                        .imageEngine(new GlideEngine())
                         // Default is `true`
                        .forResult(REQUEST_CODE_CHOOSE);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_CHOOSE && resultCode == RESULT_OK) {
         //   mAdapter.setData(Matisse.obtainResult(data), Matisse.obtainPathResult(data));
            Log.e("OnActivityResult ", String.valueOf(Matisse.obtainOriginalState(data)));
            Log.e("OnActivityResult ", Matisse.obtainResult(data).toString());
            Uri uri= Matisse.obtainResult(data).get(0);
            String path=getFilePathFromContentUri(uri, MainActivity.this.getContentResolver());
            //处理UI
            show_pic_image_view.setImageURI(uri);
            getPhotoLocation(path);
            System.out.println(path);
        }
    }
    public boolean CheckPermisson(String[] perssionGroup){
        for (String permisson:perssionGroup){
            if (ContextCompat.checkSelfPermission(this,permisson)
                    != PackageManager.PERMISSION_GRANTED)
                return true;//只要权限组里有一个权限未被授予权限，便返回true以执行requestPermission的if
        }
        return false;
    }
    public void requestPermission(String [] perssionGroup){
        if (CheckPermisson(perssionGroup)){//检测应用是否被授予危险权限，如果被授予则返回PERMISSION_GRANTED
            //接着判断这个权限是否曾经被拒绝过
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.CAMERA)){

            }else{
                //在此处成组申请权限
                ActivityCompat.requestPermissions(this,perssionGroup,1);

            }


        }


    }
    public static String getFilePathFromContentUri(Uri selectedVideoUri, ContentResolver contentResolver) {
        String filePath;
        String[] filePathColumn = {MediaStore.MediaColumns.DATA};

        Cursor cursor = contentResolver.query(selectedVideoUri, filePathColumn, null, null, null);
//      也可用下面的方法拿到cursor
//      Cursor cursor = this.context.managedQuery(selectedVideoUri, filePathColumn, null, null, null);

        cursor.moveToFirst();

        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        filePath = cursor.getString(columnIndex);
        cursor.close();
        return filePath;
    }
    public static String getRealFilePath(final Context context, final Uri uri ) {

        if ( null == uri ) return null;

        final String scheme = uri.getScheme();

        String data = null;

        if ( scheme == null )

            data = uri.getPath();

        else if ( ContentResolver.SCHEME_FILE.equals( scheme ) ) {

            data = uri.getPath();

        } else if ( ContentResolver.SCHEME_CONTENT.equals( scheme ) ) {

            Cursor cursor = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                cursor = context.getContentResolver().query( uri,new String[] { MediaStore.Images.ImageColumns.DATA },null,null );
            }

            if ( null != cursor ) {

                if ( cursor.moveToFirst() ) {

                    int index = cursor.getColumnIndex( MediaStore.Images.ImageColumns.DATA );

                    if ( index > -1 ) {

                        data = cursor.getString( index );

                    }

                }

                cursor.close();

            }

        }

        return data;

    }
    public PicInfo getPhotoLocation(String imagePath) {
        Log.i("TAG", "getPhotoLocation==" + imagePath);
        PicInfo picInfo = null;
        float  output1=0;
        float  output2=0;

        try {
            ExifInterface exifInterface = new ExifInterface(imagePath);
            String datetime = exifInterface.getAttribute(ExifInterface.TAG_DATETIME);// 拍摄时间
            String deviceName = exifInterface.getAttribute(ExifInterface.TAG_MAKE);// 设备品牌
            String deviceModel = exifInterface.getAttribute(ExifInterface.TAG_MODEL); // 设备型号
            String latValue = exifInterface.getAttribute(ExifInterface.TAG_GPS_LATITUDE);
            String lngValue = exifInterface.getAttribute(ExifInterface.TAG_GPS_LONGITUDE);
            String latRef = exifInterface.getAttribute(ExifInterface.TAG_GPS_LATITUDE_REF);
            String lngRef = exifInterface.getAttribute
                    (ExifInterface.TAG_GPS_LONGITUDE_REF);
            if (latValue != null && latRef != null && lngValue != null && lngRef != null) {
                try {
                   output1 = convertRationalLatLonToFloat(latValue, latRef);//纬度
                    output2 = convertRationalLatLonToFloat(lngValue, lngRef);//经度
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                }
            }

            Toast.makeText(this, deviceName + ":" + deviceModel, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Toast.makeText(this, output1 + ";" + output2 , Toast.LENGTH_LONG).show();

        picInfo = new PicInfo(output1 , output2 );
        return picInfo;
    }
    private static float convertRationalLatLonToFloat(
            String rationalString, String ref) {

        String[] parts = rationalString.split(",");

        String[] pair;
        pair = parts[0].split("/");
        double degrees = Double.parseDouble(pair[0].trim())
                / Double.parseDouble(pair[1].trim());

        pair = parts[1].split("/");
        double minutes = Double.parseDouble(pair[0].trim())
                / Double.parseDouble(pair[1].trim());

        pair = parts[2].split("/");
        double seconds = Double.parseDouble(pair[0].trim())
                / Double.parseDouble(pair[1].trim());

        double result = degrees + (minutes / 60.0) + (seconds / 3600.0);
        if ((ref.equals("S") || ref.equals("W"))) {
            return (float) -result;
        }
        return (float) result;
    }
    private void getAddress(double latitude, double longitude) {

        Geocoder gc = new Geocoder(MainActivity.this, Locale.getDefault());
        try {
            List<Address> locationList = gc.getFromLocation(latitude, longitude, 1);
            if (locationList != null && locationList.size()>0) {
                Address address = locationList.get(0);
                String countryName = address.getCountryName();
                String countryCode = address.getCountryCode();
                String adminArea = address.getAdminArea();
                String locality = address.getLocality();
                String subAdminArea = address.getSubLocality();
                String featureName = address.getFeatureName();

                for (int i = 0; address.getAddressLine(i) != null; i++) {
                    String addressLine = address.getAddressLine(i);
                    System.out.println("addressLine=====" + addressLine);
                }

                String currentPosition = "countryName == " + countryName
                        + "\n" + "countryCode == " + countryCode
                        + "\n" + "adminArea == " + adminArea
                        + "\n" + "locality ==" + locality
                        + "\n" + "subAdminArea == " + subAdminArea
                        + "\n" + "featureName == " + featureName;
                System.out.println(currentPosition);
            }else{
                Toast.makeText(MainActivity.this,"无法获取地址",Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
