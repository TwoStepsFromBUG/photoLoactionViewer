package com.example.photolocationchecker;

public class PicInfo {
    double latitude;
    double longitude;
    public PicInfo(float output1, float output2) {
        this.latitude=output1;
        this.longitude=output2;
    }
}
